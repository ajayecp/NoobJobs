export interface Pessoa{
    IdPessoaInstituicao?: number;
    Uf?: string;
    CpfCnpj?: string;
    Email?: string;
    FlgStatusCadastro?: number;
}
