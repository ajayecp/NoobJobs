import * as nodemailer from "nodemailer";

class Mail {

    constructor(
        public to?: string,
        public subject?: string,
        public message?: string) { }


    sendMail() {

        let mailOptions = {
            from: "noobjobs.com.br@gmail.com",
            to: this.to,
            subject: this.subject,
            html: this.message
        };

        const transporter = nodemailer.createTransport({
            //pool: true,
            service: 'gmail', 
            //host: 'mail.hugomesquita.com.br',
            //port: 465,
            //secure: true,
            auth: {
                user: 'noobjobs.com.br@gmail.com',
                pass: 'noob2526!' //'7#D5G#3PZtqj' //esconder senha (buscar da variavel de ambiente)
            },
            //tls: { rejectUnauthorized: false }
        });

        //console.log(mailOptions);

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                return error;
            } else {
                console.log("Message sent: %s", info.messageId);
                console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
                //return "E-mail enviado com sucesso!";
            }
        });
    }


}

export default new Mail;