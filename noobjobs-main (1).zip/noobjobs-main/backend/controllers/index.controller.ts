import {Request, Response} from 'express';

export function indexHome(req: Request, res:Response): Response{
    return res.json('API');
}