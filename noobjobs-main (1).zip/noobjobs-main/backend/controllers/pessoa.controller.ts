import { Request, Response } from "express";
import { connect } from "../database";
import { Pessoa } from "../interface/Pessoa.interface";
import Mail  from "../services/mail";



export async function getPessoa(req: Request, res: Response): Promise<Response>{
    const conexao = await connect();
    const pessoa = await conexao.query('SELECT * FROM tb_Pessoa');
    return res.json(pessoa[0]);
}

export async function createPessoa(req: Request, res: Response) {
   
    const conexao = await connect();

    //checar o cpfcnpj antes de inserir, usar try{}catch
    //await conexao.query('INSERT INTO tb_Pessoa set ?', [newPessoa]);
    //const newEmail: string      = req.body.Email;
    const newCpfCnpj: any    = req.body.CpfCnpj;
    const verificaCpfCnpj: any  = await isCpfCnpj(newCpfCnpj);
    console.log(newCpfCnpj);
    console.log(verificaCpfCnpj);



    if(verificaCpfCnpj === 0){
        console.log('não existe');
        const newPessoa: Pessoa = req.body;
        await conexao.query('INSERT INTO tb_Pessoa set ?', [newPessoa]);
        const newEmail: string      = req.body.Email;
        const result =  await customEnviarEmail(newEmail);

        return res.json({
            message_email: result,
            message: 'Usuário criado com sucesso' 
        });

    }else if(verificaCpfCnpj == 1){
        console.log('existe');
        //se já existe e o cadastro não tiver completo, enviar um email para validar e completar
        
        return res.json({
            message: 'Sua conta já existe'
        });

    }else{
        console.log('existe');
        return res.json({
            message: 'Sua conta já existe, Complete seu Cadastro!'
        });

    }



}

export async function getPessoaId(req: Request, res: Response): Promise<Response>{
    const id = req.params.IdPessoa;
    const conexao = await connect();
    const [pessoa] = await conexao.query('SELECT * FROM tb_Pessoa where IdPessoa = ?', [id]) as any;
    let tempResult: any = pessoa;
    //console.log(tempResult[0].Email);

    //deve ficar na parte de cadastro de pessoa
    // const message = Object.assign({}, req.body);    
    /*const message = Object.assign({}, {
            "to":"hugomesquitaweb@gmail.com", 
            "subject": "Esse é campo assunto ✔",
            "message": "Campo mensagem onde ficará o texto e link para validação"
    }); 

    Mail.to = message.to;
    Mail.subject = message.subject;
    Mail.message = message.message;
    Mail.sendMail();
    return res.status(200).json({ 
        message: 'Valide sua Conta!' 
    });*/
    return res.json(tempResult);
}

export async function deletePessoaId(req: Request, res: Response): Promise<Response>{
    const id = req.params.IdPessoa;
    const conexao = await connect();
    await conexao.query('DELETE FROM tb_Pessoa where IdPessoa = ?', [id]);
    return res.json({
        message: 'Usuário deletado com sucesso'
    });
}

export async function updatePessoaId(req: Request, res: Response): Promise<Response>{
    const id = req.params.IdPessoa;
    const updatePessoa: Pessoa = req.body;
    const conexao = await connect();
    await conexao.query('UPDATE tb_Pessoa set ? where IdPessoa = ?', [updatePessoa, id]);
    return res.json({
        message: 'Usuário atualizado com sucesso!'
    })
}

export async function customEnviarEmail(email: string){
    const message = Object.assign({}, {
        "to": email, 
        "subject": "Campo assunto ✔",
        "message": "Campo mensagem onde ficará o texto e link para validação"
    });
    Mail.to = message.to;
    Mail.subject = message.subject;
    Mail.message = message.message;
    Mail.sendMail();
    
    return 'E-Mail Enviado!';
}

export async function isCpfCnpj(cpfcnpj: any) {
    const conexao = await connect();
    const [is_pessoa] = await conexao.query('SELECT * FROM tb_Pessoa where CpfCnpj = ?', [cpfcnpj]);
    const tempResult: any = is_pessoa;

    if(Object.keys(is_pessoa).length === 0){
        return 0; //não existe
    }else{
        //verificar o status caso já exista
        
        if(tempResult[0].FlgStatusCadastro === 0){
            return 2; // realizar redirect ou exibir a mensagem para completar o cadastro
        }else{
            return 1; //(existe) e se for 1, cadastro liberado
        }

    }
}