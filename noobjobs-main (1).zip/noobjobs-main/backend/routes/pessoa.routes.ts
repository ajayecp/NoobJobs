import {Router} from 'express';
const router = Router();
import { getPessoa, createPessoa, getPessoaId, deletePessoaId, updatePessoaId } from '../controllers/pessoa.controller';

router.route('/')
    .get(getPessoa)
    .post(createPessoa)


router.route('/:IdPessoa')
    .get(getPessoaId)
    .delete(deletePessoaId)
    .put(updatePessoaId)

export default router;