"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.indexHome = void 0;
function indexHome(req, res) {
    return res.json('API');
}
exports.indexHome = indexHome;
