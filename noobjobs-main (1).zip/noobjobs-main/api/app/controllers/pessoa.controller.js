"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isCpfCnpj = exports.customEnviarEmail = exports.updatePessoaId = exports.deletePessoaId = exports.getPessoaId = exports.createPessoa = exports.getPessoa = void 0;
const database_1 = require("../database");
const mail_1 = __importDefault(require("../services/mail"));
function getPessoa(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const conexao = yield (0, database_1.connect)();
        const pessoa = yield conexao.query('SELECT * FROM tb_Pessoa');
        return res.json(pessoa[0]);
    });
}
exports.getPessoa = getPessoa;
function createPessoa(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const conexao = yield (0, database_1.connect)();
        const newCpfCnpj = req.body.CpfCnpj;
        const verificaCpfCnpj = yield isCpfCnpj(newCpfCnpj);
        console.log(newCpfCnpj);
        console.log(verificaCpfCnpj);
        if (verificaCpfCnpj === 0) {
            console.log('não existe');
            const newPessoa = req.body;
            yield conexao.query('INSERT INTO tb_Pessoa set ?', [newPessoa]);
            const newEmail = req.body.Email;
            const result = yield customEnviarEmail(newEmail);
            return res.json({
                message_email: result,
                message: 'Usuário criado com sucesso'
            });
        }
        else if (verificaCpfCnpj == 1) {
            console.log('existe');
            return res.json({
                message: 'Sua conta já existe'
            });
        }
        else {
            console.log('existe');
            return res.json({
                message: 'Sua conta já existe, Complete seu Cadastro!'
            });
        }
    });
}
exports.createPessoa = createPessoa;
function getPessoaId(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const id = req.params.IdPessoa;
        const conexao = yield (0, database_1.connect)();
        const [pessoa] = yield conexao.query('SELECT * FROM tb_Pessoa where IdPessoa = ?', [id]);
        let tempResult = pessoa;
        return res.json(tempResult);
    });
}
exports.getPessoaId = getPessoaId;
function deletePessoaId(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const id = req.params.IdPessoa;
        const conexao = yield (0, database_1.connect)();
        yield conexao.query('DELETE FROM tb_Pessoa where IdPessoa = ?', [id]);
        return res.json({
            message: 'Usuário deletado com sucesso'
        });
    });
}
exports.deletePessoaId = deletePessoaId;
function updatePessoaId(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const id = req.params.IdPessoa;
        const updatePessoa = req.body;
        const conexao = yield (0, database_1.connect)();
        yield conexao.query('UPDATE tb_Pessoa set ? where IdPessoa = ?', [updatePessoa, id]);
        return res.json({
            message: 'Usuário atualizado com sucesso!'
        });
    });
}
exports.updatePessoaId = updatePessoaId;
function customEnviarEmail(email) {
    return __awaiter(this, void 0, void 0, function* () {
        const message = Object.assign({}, {
            "to": email,
            "subject": "Campo assunto ✔",
            "message": "Campo mensagem onde ficará o texto e link para validação"
        });
        mail_1.default.to = message.to;
        mail_1.default.subject = message.subject;
        mail_1.default.message = message.message;
        mail_1.default.sendMail();
        return 'E-Mail Enviado!';
    });
}
exports.customEnviarEmail = customEnviarEmail;
function isCpfCnpj(cpfcnpj) {
    return __awaiter(this, void 0, void 0, function* () {
        const conexao = yield (0, database_1.connect)();
        const [is_pessoa] = yield conexao.query('SELECT * FROM tb_Pessoa where CpfCnpj = ?', [cpfcnpj]);
        const tempResult = is_pessoa;
        if (Object.keys(is_pessoa).length === 0) {
            return 0;
        }
        else {
            if (tempResult[0].FlgStatusCadastro === 0) {
                return 2;
            }
            else {
                return 1;
            }
        }
    });
}
exports.isCpfCnpj = isCpfCnpj;
