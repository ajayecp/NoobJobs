"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const router = (0, express_1.Router)();
const pessoa_controller_1 = require("../controllers/pessoa.controller");
router.route('/')
    .get(pessoa_controller_1.getPessoa)
    .post(pessoa_controller_1.createPessoa);
router.route('/:IdPessoa')
    .get(pessoa_controller_1.getPessoaId)
    .delete(pessoa_controller_1.deletePessoaId)
    .put(pessoa_controller_1.updatePessoaId);
exports.default = router;
