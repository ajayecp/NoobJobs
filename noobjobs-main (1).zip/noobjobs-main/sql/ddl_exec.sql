show databases;

create database noobjobs;
use noobjobs;

drop table tb_Operador;
drop table tb_Pessoa;
drop table tb_Uf;
drop table tb_PessoaCategoria;
drop table tb_PessoaInstituicao;
drop table tb_PessoaPerfil;
drop table tb_CandidatoInscricao;
drop table tb_CandidatoInscricaoProcesso; 
drop table tb_Notificacao;
drop table tb_Chat 



-- criar tabela operador
create table if not exists tb_Operador(
	IdOperador smallint not null auto_increment,
	IdPessoa smallint null comment 'fk na tb_Pessoa',
	Login varchar(50) not null,
	Senha varchar(50) not null,
	Email varchar(50) not null,
	IpTerminal varchar(50) not null,
	DtHrCadastro datetime default now() not null,
	-- DtHrValidade date null,
	primary key (IdOperador),
	constraint fk_id_operador_pessoa
	foreign key (IdPessoa) references tb_Pessoa(IdPessoa)
);

select * from tb_Operador
insert into tb_Operador(Login, Senha, Email, IpTerminal) 
values ('yyyy','123','luis@gmail.com','127.0.0.1');

-- tabela informações da pessoa 
create table if not exists tb_Pessoa(
	IdPessoa smallint not null auto_increment,	
	IdPessoaCategoria smallint null comment 'fk na tb_PessoaCategoria', -- estagiário, empresa, universidade 
	-- IdPessoaInstituicao smallint not null comment 'relação com a tbl_PessoaInstituicao',
	PathImagem varchar(100) null,
	NomePessoa varchar(150) null,
	RazaoSocial varchar(200) null,
	NomeFantasia varchar(200) null,
	TipoPessoa char(1) null comment 'J=Juridico ou F=Fisica', 
	Uf char(2) not null comment 'fk na tb_Uf',
	CpfCnpj varchar(20) null,
	Telefone varchar(15) null,
	Celular varchar(15) null,
	Email varchar(150)  null,
	IpTerminal varchar(50) null,
	FlgStatusCadastro int not null default 0 commet '0=incompleto; 1=completo',  --acrescentado realizar alter table add
	DtHrCadastro datetime default now() not null,
	primary key(IdPessoa),
	constraint cpfcnpj unique(CpfCnpj),
	constraint fk_pessoa_categoria
	foreign key (IdPessoaCategoria) references tb_PessoaCategoria(IdPessoaCategoria),
	constraint fk_pessoa_uf foreign key(Uf) references tb_Uf(Uf)
	
	-- constraint fk_id_pessoa_instituicao
	-- foreign key (IdPessoaInstituicao) references tbl_PessoaInstituicao(IdPessoaInstituicao),
);

select * from tb_PessoaCategoria

insert into tb_Pessoa (IdPessoaCategoria, Uf, CpfCnpj, Email) values (1,'AM', '111.111.111-11','hugomesquitaweb@gmail.com'); -- estagiário
insert into tb_Pessoa (IdPessoaCategoria, TipoPessoa, Uf, CpfCnpj, Email) 
values (2,'J','AM', '11.111.111/1111-11','hugomesquitaweb@gmail.com'); -- Universidade
insert into tb_Pessoa (IdPessoaCategoria, TipoPessoa, Uf, CpfCnpj, Email) -- Empresa
values (3,'J', 'AM', '22.222.222/2222-22','hugomesquitaweb@gmail.com');
select * from tb_Pessoa
/*realizar primeiro o insert na tabela pessoa, após o insert (enviar um email para pessoa validar*/
/*não pode cadastrar o mesmo cpfcnpj (fazer uma função para checar se já existe o cpfcnpj cadastrado*/
/*se já existe, checar se ele já concluiu o cadastro verificando se o idpessoa que tá cadastrado na tabela pessoa existe na tabela operador*/
/*se não existe, concluido o cadastro na tabela operador e depois validando*/


-- fazer tabela que armazena todas as estado/cidades
create table if not exists tb_Uf(
	CodigoIbge smallint not null,
	Uf char(2) not null,
	NomeEstado varchar(25) not null,
	primary key(Uf)
);
insert into tb_Uf(CodigoIbge, Uf, NomeEstado) values
(12,'AC','ACRE'),
(27,'AL','ALAGOAS'),
(16,'AP','AMAPÁ'),
(13,'AM','AMAZONAS'),
(29,'BA','BAHIA'),
(23,'CE','CEARÁ'),
(53,'DF','DISTRITO FEDERAL'),
(32,'ES','ESPÍRITO SANTOS'),
(52,'GO','GOIÁS'),
(21,'MA','MARANHÃO'),
(51,'MT','MATO GROSSO'),
(50,'MS','MATO GROSSO SO SUL'),
(31,'MG','MINAS GERAIS'),
(15,'PA','PARÁ'),
(25,'PB','PARAÍBA'),
(41,'PR','PARANÁ'),
(26,'PE','PERNAMBUCO'),
(22,'PI','PIAUÍ'),
(33,'RJ','RIO DE JANEIRO'),
(24,'RN','RIO GRANDE DO NORTE'),
(43,'RS','RIO GRANDE DO SUL'),
(11,'RO','RONDÔNIA'),
(14,'RR','RORAIMA'),
(42,'SC','SANTA CATARINA'),
(35,'SP','SÃO PAULO'),
(28,'SE','SERGIPE'),
(17,'TO','TOCANTINS'),
(99,'EX','EXTERIOR'); 

select * from tb_Uf

-- relação da pessoa com a categoria 
create table if not exists tb_PessoaCategoria(
	IdPessoaCategoria smallint not null auto_increment,
	Nome varchar(50) not null,
	primary key(IdPessoaCategoria)
);
insert into tb_PessoaCategoria (Nome) values ('Estagiário');
insert into tb_PessoaCategoria (Nome) values ('Universidade');
insert into tb_PessoaCategoria (Nome) values ('Empresa');
select * from tb_PessoaCategoria;


-- relação da pessoa com a instituicao (empresa ou universidade)
create table if not exists tb_PessoaInstituicao(
	IdPessoaInstituicao smallint not null auto_increment,
	IdPessoa smallint null comment 'fk na tb_Pessoa',
	Nome varchar(200) not null,
	Detalhe text null,
	primary key(IdPessoaInstituicao),
	constraint fk_id_pessoa
	foreign key (IdPessoa) references tb_Pessoa(IdPessoa)	
);
insert into tb_PessoaInstituicao (IdPessoa, Nome, Detalhe) values (2,'UniNorte','Informações da faculdade, texto, texto, texto, texto, texto, texto');
select * from tb_PessoaInstituicao

-- detalhe do perfil da pessoa
create table if not exists tb_PessoaPerfil(
	IdPessoaPerfil smallint not null auto_increment,
	IdPessoa smallint not null commet 'fk na tb_Pessoa',
	FlgExperiencia char(1) not null comment 'S=Sim; N=Não',
	FlgStatusProcesso tinyint null, -- remover (pensar)
	IdPessoaCargo smallint null, -- fazer uma tabela que armazena todos os cargos
	Tag varchar(100) null,
	PathMaterial varchar(150) null,
	Detalhe text null,
	LinkExterno1 varchar(50) null,
	LinkExterno2 varchar(50) null,
	LinkExterno3 varchar(50) null,
	primary key(IdPessoaPerfil),
	constraint fk_pessoa_perfil
	foreign key (IdPessoa) references tb_Pessoa(IdPessoa) on delete cascade on update cascade,
	
	constraint fk_pessoa_cargo
	foreign key (IdPessoaCargo) references tb_PessoaCargo(IdPessoaCargo)
);
insert into tb_PessoaPerfil (IdPessoa,FlgExperiencia) values(1,'S');
select * from tb_PessoaPerfil 



alter table tb_PessoaPerfil 
add constraint fk_pessoa_cargo foreign key (IdPessoaCargo) references tb_PessoaCargo(IdPessoaCargo)

create table if not exists tb_PessoaCargo(
	IdPessoaCargo smallint not null auto_increment,
	Nome varchar(150) not null,
	primary key(IdPessoaCargo)
);

insert into tb_PessoaCargo (Nome) values
('Desenvolvedor Front-End'),
('Desenvolvedor Back-End'),
('Devops'),
('Marketing'),
('Designer'),
('Vídeo Maker'),
('Programador'),
('Auxiliar de Cozinha'),
('Comercial'),
('Financeiro'),
('Compras'),
('Contabilidade')

select * from tb_PessoaCargo
-- fazer tabela que armazena PessoaDocumento
pk IdPessoadocumento
fk IdPessoa 
TipoDocumento	(cpf, rg, comporvante de residência) -- carteira de trabalho
PathDocumento
Observacao varchar(250)
dthrCadastro

-- fazer tabela que armazena os cargos 




-- ato da inscrição do candidato na empresa ou empresa ao candidato
-- criar um job de monitoramento sempre que ocorrer uma atualização no flgStatusProcesso e inserir na tabela de notificação
-- relação de pessoa ou candidato inscrito (criar uma trigger sempre que ocorrer uma novo registro realizar o update na tbl_PessoaPerfil pertencente ao novo status)
-- quando o processo de inscrição chegar no status 3, disparar um gatilho para criar uma notificação na tabela notificação
drop table tb_CandidatoInscricao
create table if not exists tb_CandidatoInscricao(
	IdCandidatoInscricao smallint not null auto_increment,
	IdPessoaPerfil smallint not null comment 'fk na tb_PessoaPerfil',
	IdPessoaInstituicao smallint not null comment 'fk na tb_PessoaInstituicao',
	FlgStatusProcesso tinyint not null comment '0=Novo Candidato, 1=Em Analise, 2=Apto para Próxima Etapa, 3=Apto para Entrevista, 4=Selecionado, 5=Cancelado', -- (fazer tabela) pensar na possibilidade de armazenar essa informação em outra tabela com o período 
	IpTerminal varchar(50) not null,
	DtHrCadastro datetime default now() not null,
	primary key(IdCandidatoInscricao),
	constraint fk_candidato_perfil 
	foreign key (IdPessoaPerfil) references tb_PessoaPerfil(IdPessoaPerfil),
	constraint fk_candidato_instituicao
	foreign key (IdPessoaInstituicao) references tb_PessoaInstituicao(IdPessoaInstituicao)
);



/*CORRIGIR*/
select * from tb_CandidatoInscricao
insert into tb_CandidatoInscricao (IdPessoaPerfil,IdPessoaInstituicao, FlgStatusProcesso, IpTerminal) 
values (1,1,0,'127.0.0.1');
update tb_CandidatoInscricao set FlgStatusProcesso = 3 where IdCandidatoInscricao = 2


drop trigger tg_inscricao_insert
create or replace trigger tg_inscricao_insert 
after insert on tb_CandidatoInscricao
for each row 
begin
	insert into tb_CandidatoInscricaoProcesso (IdCandidatoInscricao, IdPessoaInstituicao, IdOperador,FlgStatusProcesso,IpTerminal) 
	values (new.IdCandidatoInscricao, new.IdPessoaInstituicao,null,new.FlgStatusProcesso,new.IpTerminal);
end;

-- colocar o insert aqui para registrar as operações na tabela de tb_CandidatoInscricaoProcesso
-- após inserir na tb_CandidatoInscricaoProcesso atualizar o último status na tb_CandidatoInscricao fazendo um update 
create or replace trigger tg_inscricao_update
after update on tb_CandidatoInscricao
for each row 
begin
	if new.FlgStatusProcesso <> old.FlgStatusProcesso then 
		/*update tb_CandidatoInscricao set FlgStatusProcesso = new.FlgStatusProcesso 
		where IdCandidatoInscricao = old.IdCandidatoInscricao;*/
		insert into tb_CandidatoInscricaoProcesso (IdCandidatoInscricao, IdPessoaInstituicao,IdOperador,FlgStatusProcesso,IpTerminal) 
		values (new.IdCandidatoInscricao, new.IdPessoaInstituicao, null, new.FlgStatusProcesso, new.IpTerminal); 
	end if;

	if new.FlgStatusProcesso = 3 then 
		insert into tb_Notificacao (IdPessoaInstituicao, IdPessoaPerfil, Titulo, Mensagem) 
		values (new.IdPessoaInstituicao, new.IdPessoaPerfil, 'Titulo da Notificação','Mensagem da Notificação');
	end if;
end;


-- histórico da evolução do candidato , criar uma trigger para sempre que ocorrer um insert atualizar a tabela candidato inscricao na coluna flgstatusprocesso
-- fazer uma tabela de processos que envolve aquela pessoa inscrita relacionado a pessoa e empresa (fazer uma tabela tbl_CanditadoInscricaoProcesso)
-- tabela de histórico de processo dos candidatos inscritos
drop table tb_CandidatoInscricaoProcesso 
create table if not exists tb_CandidatoInscricaoProcesso(
	IdCandidatoInscricaoProcesso smallint not null auto_increment,
	IdCandidatoInscricao smallint not null comment 'fk na tb_CandidatoInscricao',
	IdPessoaInstituicao smallint not null comment 'fk na tb_PessoaInstituicao',
	IdOperador smallint null,
	FlgStatusProcesso tinyint not null comment '0=Novo Candidato, 1=Em Analise, 2=Apto para Próxima Etapa, 3=Apto para Entrevista, 4=Selecionado, 5=Cancelado', -- (fazer tabela) pensar na possibilidade de armazenar essa informação em outra tabela com o período 
	IpTerminal varchar(50) not null,
	DtHrCadastro datetime default now() not null,
	primary key(IdCandidatoInscricaoProcesso),
	
	constraint fk_pessoa_inscricao 
	foreign key(IdCandidatoInscricao) references tb_CandidatoInscricao(IdCandidatoInscricao),
	
	constraint fk_pessoa_instituica
	foreign key(IdPessoaInstituicao) references tb_PessoaInstituicao(IdPessoaInstituicao),
	
	
	constraint fk_pessoa_operador
	foreign key(IdOperador) references tb_Operador(IdOperador)
);

select * from tb_CandidatoInscricaoProcesso

-- fazer tabela para relação de candidato empregado (monitorando o período=2anos, fica disponível para o mercado)

-- fazer tabela de notificacao 
idnotificacao
idPessoaInstituicao
idPessoaPerfil
Titulo 
Mensagem
DtHrCadastro
-- criar uma trigger para quando chegar no status de interesse(entrevista) inserir uma notificação
create table if not exists tb_Notificacao(
	IdNotificacao smallint not null auto_increment,
	IdPessoaInstituicao smallint not null comment 'fk na tb_PessoaInstituicao',
	IdPessoaPerfil smallint not null comment 'fk na tb_PessoaPerfil', 
	Titulo varchar(50) not null,
	Mensagem text null,
	DtHrCadastro datetime default now() not null,
	primary key(IdNotificacao),
	constraint fk_notificacao_pessoa_instituicao
	foreign key(IdPessoaInstituicao) references tb_PessoaInstituicao(IdPessoaInstituicao),
	constraint fk_notificacao_pessoa_perfil
	foreign key(IdPessoaPerfil) references tb_PessoaPerfil(IdPessoaPerfil)
);

select * from tb_Notificacao
insert into tb_Notificacao (IdPessoaInstituicao,IdPessoaPerfil,Titulo, Mensagem) values ()


-- fazer tabela do chat, IdOrigem e IdDestino 
IdNotificacao
IdPessoaOrigem
IdPessoaDestino
Mensagem
DtHrCadastro
DtHrLido
FlgDeletado 
create table if not exists tb_Chat(
	IdChat smallint not null auto_increment,
	IdNotificacao smallint not null comment 'fk na tb_Notificacao',
	IdPessoaOrigem smallint not null,
	IdPessoaDestino smallint not null,
	Mensagem text,
	DtHrCadastro datetime default now() not null,
	DtHrLido datetime null,
	FlgDeletado char(1) null comment 'S=Sim; N=Não',
	primary key(IdChat),
	constraint fk_chat_notificacao
	foreign key(IdNotificacao) references tb_Notificacao(IdNotificacao)
);

select * from tb_Chat 
insert into tb_Chat (IdNotificacao,IdPessoaOrigem,IdPessoaDestino,Mensagem) 
values ()


select * from tb_Pessoa p where p.IdPessoa = (select op.IdPessoa from tb_Operador op)
select * from tb_Operador op



/*Stored Procedure*/
create procedure if not exists sp_auth(
	
)
begin
	
end;

